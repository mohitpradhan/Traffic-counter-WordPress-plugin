Plugin Name: My Traffic Counter
Developed by: Mohit Pradhan
Website: www.mohitpradhan.com

Installing Instructions:

1. Goto your WordPress Dashboard and click on plugins>Add new 

2. Search for "My Traffic Counter" and click on install from the search results.

3. Alternatively you can also download the plugin and upload its zip file for installing.

4. Goto Appearance>Widgets and use the 'My traffic counter widget' on any of your headers, footers, sidebars, etc.

5. You can change the font and colors through the widget.

Compatible with latest WordPress version 4.9
